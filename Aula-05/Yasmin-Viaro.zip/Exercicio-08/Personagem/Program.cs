﻿internal class Program
{
    private static void Main(string[] args)
    {
        
    }

    public class Personagem
    {
        public string Nome {get; private set;}
        public int Nivel {get; private set;}
        public int Forca {get; private set;}
    }
}